<?php

trait TieneFecha {
    private $fecha;
    function getFecha() { return $this->fecha; }
    function setFecha($fecha) { $this->fecha = $fecha; }
}
?>